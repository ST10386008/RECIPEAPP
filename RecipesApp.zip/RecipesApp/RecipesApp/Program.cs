﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApplication
{
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
    }

    class Step
    {
        public string Description { get; set; }
    }

    class Recipe
    {
        private Ingredient[] ingredients;
        private Ingredient[] originalQuantities; // Added for ResetQuantities method
        private Step[] steps;

        public void SetIngredients(int count)
        {
            ingredients = new Ingredient[count];
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"Enter details for ingredient {i + 1}:");
                ingredients[i] = new Ingredient();
                Console.Write("Name: ");
                ingredients[i].Name = Console.ReadLine();
                Console.Write("Quantity: ");
                ingredients[i].Quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit: ");
                ingredients[i].Unit = Console.ReadLine();
            }

            // Backup original quantities for ResetQuantities method
            originalQuantities = new Ingredient[count];
            Array.Copy(ingredients, originalQuantities, count);
        }

        public void SetSteps(int count)
        {
            steps = new Step[count];
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                steps[i] = new Step();
                Console.Write("Description: ");
                steps[i].Description = Console.ReadLine();
            }
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("\nRecipe:");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i].Description}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            for (int i = 0; i < ingredients.Length; i++)
            {
                ingredients[i].Quantity = originalQuantities[i].Quantity;
            }
        }

        public void ClearRecipe()
        {
            ingredients = null;
            steps = null;
            originalQuantities = null; 
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            Console.WriteLine("Enter the details for the recipe:");

            Console.Write("Number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());
            recipe.SetIngredients(ingredientCount);

            Console.Write("Number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());
            recipe.SetSteps(stepCount);

            recipe.DisplayRecipe();

            Console.WriteLine("\nDo you want to scale the recipe? (Y/N)");
            if (Console.ReadLine().ToUpper() == "Y")
            {
                Console.Write("Enter the scale factor (0.5, 2, or 3): ");
                double factor = double.Parse(Console.ReadLine());
                recipe.ScaleRecipe(factor);
                recipe.DisplayRecipe();
            }

            Console.WriteLine("\nDo you want to reset the quantities to original values? (Y/N)");
            if (Console.ReadLine().ToUpper() == "Y")
            {
                recipe.ResetQuantities();
                recipe.DisplayRecipe();
            }

            Console.WriteLine("\nDo you want to clear the recipe? (Y/N)");
            if (Console.ReadLine().ToUpper() == "Y")
            {
                recipe.ClearRecipe();
                Console.WriteLine("Recipe cleared.");
            }
        }
    }
}

