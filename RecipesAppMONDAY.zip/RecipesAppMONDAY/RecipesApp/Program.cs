﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApplication
{
    // Ingredient class with properties for name, quantity, unit, calories, and food group
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    // Step class with a description property
    class Step
    {
        public string Description { get; set; }
    }

    // Recipe class to manage recipes
    class Recipe
    {
        // Properties
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; } = new List<Ingredient>();
        public List<Step> Steps { get; } = new List<Step>();

        // Delegate for notifying when total calories exceed 300
        public delegate void RecipeExceedsCaloriesHandler(string recipeName, double totalCalories);

        // Event to subscribe to for notification
        public event RecipeExceedsCaloriesHandler RecipeExceedsCaloriesEvent;

        // Method to add ingredients to the recipe
        public void AddIngredient()
        {
            Console.WriteLine("Enter details for ingredients:");
            Ingredient ingredient = new Ingredient();
            Console.Write("Name: ");
            ingredient.Name = Console.ReadLine();
            Console.Write("Quantity: ");
            ingredient.Quantity = double.Parse(Console.ReadLine());
            Console.Write("Unit: ");
            ingredient.Unit = Console.ReadLine();
            Console.Write("Calories: ");
            ingredient.Calories = double.Parse(Console.ReadLine());
            Console.Write("Food Group: ");
            ingredient.FoodGroup = Console.ReadLine();
            Ingredients.Add(ingredient);
        }

        // Method to add steps to the recipe
        public void AddStep()
        {
            Console.WriteLine("Enter step:");
            Step step = new Step();
            step.Description = Console.ReadLine();
            Steps.Add(step);
        }

        // Method to display recipe details
        public void DisplayRecipe()
        {
            Console.WriteLine($"\nRecipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i].Description}");
            }
        }

        // Method to calculate total calories of the recipe
        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories * ingredient.Quantity);
        }

        // Method to check if total calories exceed 300 and notify if needed
        public void CheckCaloriesExceedLimit()
        {
            double totalCalories = CalculateTotalCalories();
            if (totalCalories > 300)
            {
                RecipeExceedsCaloriesEvent?.Invoke(Name, totalCalories);
            }
        }
    }

    // Main program
    class Program
    {
        static void Main(string[] args)
        {
            List<Recipe> recipes = new List<Recipe>();

            while (true)
            {
                Console.WriteLine("\nEnter the details for the recipe (or type 'exit' to finish):");

                Console.Write("Recipe Name: ");
                string recipeName = Console.ReadLine();
                if (recipeName.ToLower() == "exit")
                    break;

                Recipe recipe = new Recipe();
                recipe.Name = recipeName;

                Console.Write("Number of ingredients: ");
                int ingredientCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < ingredientCount; i++)
                {
                    recipe.AddIngredient();
                }

                Console.Write("Number of steps: ");
                int stepCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < stepCount; i++)
                {
                    recipe.AddStep();
                }

                recipes.Add(recipe);
            }

            // Display list of recipes in alphabetical order
            recipes = recipes.OrderBy(r => r.Name).ToList();
            Console.WriteLine("\nList of Recipes:");
            foreach (var recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }

            // User chooses a recipe to display
            Console.Write("\nEnter the name of the recipe to display: ");
            string selectedRecipeName = Console.ReadLine();
            Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(selectedRecipeName, StringComparison.OrdinalIgnoreCase));
            if (selectedRecipe != null)
            {
                selectedRecipe.DisplayRecipe();

                // Calculate and display total calories
                double totalCalories = selectedRecipe.CalculateTotalCalories();
                Console.WriteLine($"\nTotal Calories: {totalCalories}");

                // Check if total calories exceed 300
                selectedRecipe.RecipeExceedsCaloriesEvent += (name, calories) =>
                {
                    Console.WriteLine($"\nWarning: {name} has total calories exceeding 300! Total Calories: {calories}");
                };
                selectedRecipe.CheckCaloriesExceedLimit();
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }
    }
}
