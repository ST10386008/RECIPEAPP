﻿using RecipeApplicationWPF.Models;
using System.Collections.ObjectModel;
using System.Windows;

namespace RecipeApplicationWPF
{
    public partial class AddMenuWindow : Window
    {
        public ObservableCollection<Recipe> Menu { get; private set; }
        public ObservableCollection<Recipe> Recipes { get; private set; }

        public AddMenuWindow(ObservableCollection<Recipe> recipes)
        {
            InitializeComponent();
            Menu = new ObservableCollection<Recipe>();
            Recipes = recipes;
            lbRecipes.ItemsSource = Recipes;
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            Menu.Clear();
            foreach (Recipe recipe in lbRecipes.SelectedItems)
            {
                Menu.Add(recipe);
            }
            this.DialogResult = true;
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
