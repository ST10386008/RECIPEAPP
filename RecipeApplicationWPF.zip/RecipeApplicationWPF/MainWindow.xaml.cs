﻿using RecipeApplicationWPF.Models;
using LiveCharts;
using LiveCharts.Wpf;
using System.Collections.ObjectModel;
using System.Windows;
using System.Collections.Generic;

namespace RecipeApplicationWPF
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<RecipeApplicationWPF.Models.Recipe> Recipes { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            InitializeDummyData();
            DataContext = this; // Set the DataContext after InitializeComponent
        }

        private void InitializeDummyData()
        {
            Recipes = new ObservableCollection<RecipeApplicationWPF.Models.Recipe>
            {
                new RecipeApplicationWPF.Models.Recipe
                {
                    Name = "Spaghetti Bolognese",
                    Ingredients = new ObservableCollection<RecipeApplicationWPF.Models.Ingredient>
                    {
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Spaghetti", Quantity = 200, Unit = "g", FoodGroup = "Grains" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Ground Beef", Quantity = 300, Unit = "g", FoodGroup = "Protein" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Tomato Sauce", Quantity = 200, Unit = "ml", FoodGroup = "Vegetables" }
                    },
                    Steps = new ObservableCollection<RecipeApplicationWPF.Models.Step>
                    {
                        new RecipeApplicationWPF.Models.Step { Description = "Cook spaghetti according to package instructions." },
                        new RecipeApplicationWPF.Models.Step { Description = "Brown the ground beef in a pan." },
                        new RecipeApplicationWPF.Models.Step { Description = "Add tomato sauce to the beef and simmer." }
                    }
                },
                new RecipeApplicationWPF.Models.Recipe
                {
                    Name = "Chicken Salad",
                    Ingredients = new ObservableCollection<RecipeApplicationWPF.Models.Ingredient>
                    {
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Chicken Breast", Quantity = 150, Unit = "g", FoodGroup = "Protein" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Lettuce", Quantity = 100, Unit = "g", FoodGroup = "Vegetables" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Cherry Tomatoes", Quantity = 50, Unit = "g", FoodGroup = "Vegetables" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Olive Oil", Quantity = 20, Unit = "ml", FoodGroup = "Fats" }
                    },
                    Steps = new ObservableCollection<RecipeApplicationWPF.Models.Step>
                    {
                        new RecipeApplicationWPF.Models.Step { Description = "Grill the chicken breast." },
                        new RecipeApplicationWPF.Models.Step { Description = "Chop the lettuce and cherry tomatoes." },
                        new RecipeApplicationWPF.Models.Step { Description = "Mix all ingredients and drizzle with olive oil." }
                    }
                },
                new RecipeApplicationWPF.Models.Recipe
                {
                    Name = "Pancakes",
                    Ingredients = new ObservableCollection<RecipeApplicationWPF.Models.Ingredient>
                    {
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Flour", Quantity = 200, Unit = "g", FoodGroup = "Grains" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Milk", Quantity = 300, Unit = "ml", FoodGroup = "Dairy" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Egg", Quantity = 2, Unit = "pcs", FoodGroup = "Protein" },
                        new RecipeApplicationWPF.Models.Ingredient { Name = "Sugar", Quantity = 50, Unit = "g", FoodGroup = "Sugars" }
                    },
                    Steps = new ObservableCollection<RecipeApplicationWPF.Models.Step>
                    {
                        new RecipeApplicationWPF.Models.Step { Description = "Mix all ingredients to form a batter." },
                        new RecipeApplicationWPF.Models.Step { Description = "Pour batter onto a hot griddle." },
                        new RecipeApplicationWPF.Models.Step { Description = "Cook until golden brown on both sides." }
                    }
                }
            };
        }

        private void btnCreateMenu_Click(object sender, RoutedEventArgs e)
        {
            AddMenuWindow addMenuWindow = new AddMenuWindow(Recipes);
            if (addMenuWindow.ShowDialog() == true)
            {
                DisplayPieChart(addMenuWindow.Menu);
            }
        }

        private void btnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow();
            if (addRecipeWindow.ShowDialog() == true)
            {
                Recipes.Add(addRecipeWindow.Recipe);
            }
        }

        private void DisplayPieChart(ObservableCollection<RecipeApplicationWPF.Models.Recipe> menu)
        {
            pieChart.Series.Clear();
            var foodGroups = new Dictionary<string, double>();

            foreach (var recipe in menu)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    if (foodGroups.ContainsKey(ingredient.FoodGroup))
                    {
                        foodGroups[ingredient.FoodGroup] += ingredient.Quantity;
                    }
                    else
                    {
                        foodGroups[ingredient.FoodGroup] = ingredient.Quantity;
                    }
                }
            }

            foreach (var group in foodGroups)
            {
                pieChart.Series.Add(new PieSeries
                {
                    Title = group.Key,
                    Values = new ChartValues<double> { group.Value },
                    DataLabels = true
                });
            }

            pieChart.Visibility = Visibility.Visible;
        }
    }
}
