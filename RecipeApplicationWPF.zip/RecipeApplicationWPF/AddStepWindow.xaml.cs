﻿using RecipeApplicationWPF.Models;
using System.Windows;

namespace RecipeApplicationWPF
{
    public partial class AddStepWindow : Window
    {
        public Step Step { get; private set; }

        public AddStepWindow()
        {
            InitializeComponent();
            Step = new Step();
            DataContext = Step;
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
