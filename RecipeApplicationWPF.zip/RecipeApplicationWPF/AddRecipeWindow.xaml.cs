﻿using RecipeApplicationWPF.Models;
using System.Windows;

namespace RecipeApplicationWPF
{
    public partial class AddRecipeWindow : Window
    {
        public Recipe Recipe { get; private set; }

        public AddRecipeWindow()
        {
            InitializeComponent();
            Recipe = new Recipe();
            lbIngredients.ItemsSource = Recipe.Ingredients;
            lbSteps.ItemsSource = Recipe.Steps;
            DataContext = Recipe; // Set DataContext to Recipe
        }

        private void btnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            AddIngredientWindow addIngredientWindow = new AddIngredientWindow();
            if (addIngredientWindow.ShowDialog() == true)
            {
                Recipe.Ingredients.Add(addIngredientWindow.Ingredient);
            }
        }

        private void btnAddStep_Click(object sender, RoutedEventArgs e)
        {
            AddStepWindow addStepWindow = new AddStepWindow();
            if (addStepWindow.ShowDialog() == true)
            {
                Recipe.Steps.Add(addStepWindow.Step);
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
