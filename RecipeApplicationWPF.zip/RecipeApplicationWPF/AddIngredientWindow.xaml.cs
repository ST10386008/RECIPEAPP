﻿using RecipeApplicationWPF.Models;
using System.Windows;

namespace RecipeApplicationWPF
{
    public partial class AddIngredientWindow : Window
    {
        public Ingredient Ingredient { get; private set; }

        public AddIngredientWindow()
        {
            InitializeComponent();
            Ingredient = new Ingredient();
            DataContext = Ingredient;
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
