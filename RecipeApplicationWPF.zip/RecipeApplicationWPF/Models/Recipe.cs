﻿using System.Collections.ObjectModel;

namespace RecipeApplicationWPF.Models
{
    public class Recipe
    {
        public string Name { get; set; }
        public ObservableCollection<Ingredient> Ingredients { get; set; }
        public ObservableCollection<Step> Steps { get; set; }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public string FoodGroup { get; set; } // Added FoodGroup property
    }

    public class Step
    {
        public string Description { get; set; }
    }
}
